This is a simple resource monitor.
Have a happy computing!

Software Page:
http://www.moo0.com/software/SystemMonitor/#SystemMonitor

Please tell us anything to improve this software!
http://www.moo0.com/software/SystemMonitor/feedback/send/free/

Want More? Please support us via donation!
http://www.moo0.com/donate/

Using this at Work? Please obtain the license via any amount of donation!
http://www.moo0.com/commercial/


Moo0 Development Team
http://www.moo0.com/
Contact: dev@moo0.com